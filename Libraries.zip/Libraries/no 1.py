import math
#QN 1
# Prompt user to input value in degrees.
degrees = float(input('Enter a number:'))
radians = degrees * math.pi/180
# output the value in radians
print(radians)