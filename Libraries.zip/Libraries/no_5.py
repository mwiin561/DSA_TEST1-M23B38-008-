##Creating an array and determining the size of memory occupied:

import numpy as np

# Creating an array and determining the size of memory occupied
array_values = np.array([1, 7, 13, 105])
print("Array Values:", array_values)
print("Size of memory occupied by the array:", array_values.nbytes, "bytes")
