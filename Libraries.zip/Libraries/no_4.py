##Testing element-wise for complex numbers, real numbers, and scalar type:
import numpy as np

# Creating a sample array
sample_array = np.array([1, 7, 13, 105], dtype=complex)

# Testing element-wise for complex numbers and real numbers
print("Testing element-wise for complex numbers:")
print(np.iscomplex(sample_array))
print("Testing element-wise for real numbers:")
print(np.isreal(sample_array))

# Testing if a number is of scalar type
test_scalar = 5
print("Testing if a number is of scalar type:")
print(np.isscalar(test_scalar))
